import SwiftUI
import HealthKit

// MARK: - Main App
@main
struct EyeRestApp: App {
    @Environment(\.scenePhase) private var scenePhase
    @StateObject private var settingsManager = SettingsManager()
    @StateObject private var statisticsManager = StatisticsManager()
    private let notificationManager = NotificationManager()

    var body: some Scene {
        WindowGroup {
            MainTabView()
                .environmentObject(settingsManager)
                .environmentObject(statisticsManager)
                .onAppear(perform: notificationManager.requestAuthorization)
        }
        .onChange(of: scenePhase) { oldPhase, newPhase in
            switch newPhase {
            case .background:
                print("App is in background")
                // Here you would schedule a background task to keep the timer running
            case .active:
                print("App is active")
            case .inactive:
                print("App is inactive")
            @unknown default:
                print("Unknown scene phase")
            }
        }
    }
}

// MARK: - Main Tab View
struct MainTabView: View {
    @EnvironmentObject var settingsManager: SettingsManager

    var body: some View {
        TabView {
            ContentView()
                .tabItem {
                    Label("Home", systemImage: "house.fill")
                }

            SettingsView()
                .tabItem {
                    Label("Settings", systemImage: "gear")
                }

            StatisticsView()
                .tabItem {
                    Label("Stats", systemImage: "chart.bar.fill")
                }

            ExercisesView()
                .tabItem {
                    Label("Exercises", systemImage: "figure.walk")
                }
        }
        .preferredColorScheme(settingsManager.theme.colorScheme)
    }
}

// MARK: - Content View
struct ContentView: View {
    @StateObject private var timerManager = TimerManager()
    @EnvironmentObject var settingsManager: SettingsManager
    @EnvironmentObject var statisticsManager: StatisticsManager

    var body: some View {
        VStack {
            Text("Eye and Posture Rest")
                .font(.largeTitle)
                .padding()

            Text(String(format: "%02d:%02d", Int(timerManager.timeRemaining) / 60, Int(timerManager.timeRemaining) % 60))
                .font(.system(size: 80, weight: .bold, design: .monospaced))
                .padding()

            HStack(spacing: 30) {
                Button(action: {
                    timerManager.start(settings: settingsManager)
                }) {
                    Image(systemName: "play.circle.fill")
                        .resizable()
                        .frame(width: 50, height: 50)
                }

                Button(action: {
                    timerManager.stop()
                }) {
                    Image(systemName: "pause.circle.fill")
                        .resizable()
                        .frame(width: 50, height: 50)
                }

                Button(action: {
                    timerManager.reset()
                }) {
                    Image(systemName: "arrow.clockwise.circle.fill")
                        .resizable()
                        .frame(width: 50, height: 50)
                }
            }
        }
        .onAppear {
            timerManager.setup(settings: settingsManager, statisticsManager: statisticsManager)
        }
    }
}

// MARK: - App Mode
enum AppMode: String, CaseIterable, Identifiable {
    case study = "Study"
    case work = "Work"
    case gaming = "Gaming"

    var id: String { self.rawValue }
}

// MARK: - Timer Manager
class TimerManager: ObservableObject {
    @Published var timeRemaining: TimeInterval = 0
    @Published var isActive = false
    @Published var isWorkSession = true

    private var timer: Timer?
    private var settings: SettingsManager?
    private var statisticsManager: StatisticsManager?

    func setup(settings: SettingsManager, statisticsManager: StatisticsManager) {
        self.settings = settings
        self.statisticsManager = statisticsManager
        self.timeRemaining = settings.workInterval
    }

    func start(settings: SettingsManager) {
        self.settings = settings
        isActive = true
        timer = Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { _ in
            if self.timeRemaining > 0 {
                self.timeRemaining -= 1
            } else {
                self.switchSession()
            }
        }
    }

    func stop() {
        isActive = false
        timer?.invalidate()
        timer = nil
    }

    func reset() {
        stop()
        isWorkSession = true
        timeRemaining = settings?.workInterval ?? 25 * 60
    }

    private func switchSession() {
        stop()
        isWorkSession.toggle()
        if isWorkSession {
            timeRemaining = settings?.workInterval ?? 25 * 60
            NotificationManager().scheduleNotification(type: "Work session finished!", timeInterval: 1)
            statisticsManager?.logWorkSession()
        } else {
            timeRemaining = settings?.breakInterval ?? 5 * 60
            NotificationManager().scheduleNotification(type: "Break finished!", timeInterval: 1)
            statisticsManager?.logBreakSession()
        }
        AudioManager.shared.playSound()
        start(settings: settings!)
    }
}

// MARK: - Notification Manager
class NotificationManager {
    func requestAuthorization() {
        UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .badge, .sound]) { success, error in
            if success {
                print("All set!")
            } else if let error = error {
                print(error.localizedDescription)
            }
        }
    }

    func scheduleNotification(type: String, timeInterval: TimeInterval) {
        let content = UNMutableNotificationContent()
        content.title = "EyeRest"
        content.subtitle = type
        content.sound = UNNotificationSound.default

        let trigger = UNTimeIntervalNotificationTrigger(timeInterval: timeInterval, repeats: false)
        let request = UNNotificationRequest(identifier: UUID().uuidString, content: content, trigger: trigger)

        UNUserNotificationCenter.current().add(request)
    }
}

// MARK: - HealthKit Manager
class HealthKitManager {
    let healthStore = HKHealthStore()

    func requestAuthorization(completion: @escaping (Bool) -> Void) {
        guard HKHealthStore.isHealthDataAvailable() else {
            completion(false)
            return
        }

        guard let sleepType = HKObjectType.categoryType(forIdentifier: .sleepAnalysis),
              let standHourType = HKObjectType.categoryType(forIdentifier: .appleStandHour) else {
            completion(false)
            return
        }
        
        let typesToRead: Set<HKObjectType> = [sleepType, standHourType]

        healthStore.requestAuthorization(toShare: nil, read: typesToRead) { success, error in
            if let error = error {
                print("HealthKit authorization error: \(error.localizedDescription)")
            }
            completion(success)
        }
    }

    func isUserSleeping(completion: @escaping (Bool) -> Void) {
        guard let sleepType = HKObjectType.categoryType(forIdentifier: .sleepAnalysis) else {
            completion(false)
            return
        }
        
        let sortDescriptor = NSSortDescriptor(key: HKSampleSortIdentifierEndDate, ascending: false)
        let query = HKSampleQuery(sampleType: sleepType, predicate: nil, limit: 1, sortDescriptors: [sortDescriptor]) { query, samples, error in
            if let error = error {
                print("HealthKit query error: \(error.localizedDescription)")
                completion(false)
                return
            }
            
            guard let sample = samples?.first as? HKCategorySample else {
                // No sleep data found
                completion(false)
                return
            }

            // Check if the user is currently in bed or asleep
            let isSleeping = (sample.value == HKCategoryValueSleepAnalysis.inBed.rawValue || sample.value == HKCategoryValueSleepAnalysis.asleepUnspecified.rawValue)
            completion(isSleeping)
        }
        healthStore.execute(query)
    }

    func fetchStandHours(completion: @escaping (Int) -> Void) {
        guard let standHourType = HKObjectType.categoryType(forIdentifier: .appleStandHour) else {
            completion(0)
            return
        }

        let calendar = Calendar.current
        let now = Date()
        let startOfDay = calendar.startOfDay(for: now)
        let predicate = HKQuery.predicateForSamples(withStart: startOfDay, end: now, options: .strictStartDate)

        let query = HKSampleQuery(sampleType: standHourType, predicate: predicate, limit: HKObjectQueryNoLimit, sortDescriptors: nil) { query, samples, error in
            guard let samples = samples as? [HKCategorySample] else {
                completion(0)
                return
            }

            let standHours = samples.count
            completion(standHours)
        }
        healthStore.execute(query)
    }
}

// MARK: - Settings
class SettingsManager: ObservableObject {
    @Published var workInterval: TimeInterval = 25 * 60 // 25 minutes
    @Published var breakInterval: TimeInterval = 5 * 60 // 5 minutes
    @Published var theme: Theme = .system
}

struct SettingsView: View {
    @EnvironmentObject var settingsManager: SettingsManager

    var body: some View {
        NavigationView {
            Form {
                Section(header: Text("Pomodoro Timer")) {
                    Stepper("Work: \(Int(settingsManager.workInterval / 60)) min", value: $settingsManager.workInterval, in: 300...3600, step: 300)
                    Stepper("Break: \(Int(settingsManager.breakInterval / 60)) min", value: $settingsManager.breakInterval, in: 60...1800, step: 60)
                }


                Section(header: Text("Appearance")) {
                    Picker("Theme", selection: $settingsManager.theme) {
                        ForEach(Theme.allCases) { theme in
                            Text(theme.rawValue).tag(theme)
                        }
                    }
                }
            }
            .navigationTitle("Settings")
        }
    }
}


// MARK: - Statistics
class StatisticsManager: ObservableObject {
    @Published var workSessionsCompleted = 0
    @Published var breakSessionsCompleted = 0
    @Published var standHours = 0

    private let healthKitManager = HealthKitManager()

    func logWorkSession() {
        workSessionsCompleted += 1
    }

    func logBreakSession() {
        breakSessionsCompleted += 1
    }

    func fetchStandHours() {
        healthKitManager.fetchStandHours { hours in
            DispatchQueue.main.async {
                self.standHours = hours
            }
        }
    }
}

struct StatisticsView: View {
    @EnvironmentObject var statisticsManager: StatisticsManager

    var body: some View {
        NavigationView {
            Form {
                Section(header: Text("Pomodoro Stats")) {
                    Text("Work sessions completed: \(statisticsManager.workSessionsCompleted)")
                    Text("Break sessions completed: \(statisticsManager.breakSessionsCompleted)")
                }

                Section(header: Text("HealthKit Stats")) {
                    Text("Stand hours today: \(statisticsManager.standHours)")
                    Button("Refresh HealthKit Data") {
                        statisticsManager.fetchStandHours()
                    }
                }
            }
            .navigationTitle("Statistics")
        }
    }
}


// MARK: - Exercises
struct Exercise: Identifiable {
    let id = UUID()
    let name: String
    let description: String
}

class ExerciseProvider {
    static let exercises: [Exercise] = [
        Exercise(name: "Neck Rolls", description: "Slowly roll your head in a circle, first clockwise, then counter-clockwise."),
        Exercise(name: "Shoulder Shrugs", description: "Raise your shoulders up to your ears, hold for a few seconds, then relax."),
        Exercise(name: "20-20-20 Rule", description: "Every 20 minutes, look at something 20 feet away for 20 seconds."),
        Exercise(name: "4-7-8 Breathing", description: "Breathe in for 4 seconds, hold for 7 seconds, and breathe out for 8 seconds.")
    ]
}

struct ExercisesView: View {
    let exercises = ExerciseProvider.exercises

    var body: some View {
        NavigationView {
            List(exercises) { exercise in
                VStack(alignment: .leading) {
                    Text(exercise.name).font(.headline)
                    Text(exercise.description).font(.subheadline)
                }
            }
            .navigationTitle("Mini Exercises")
        }
    }
}


// MARK: - Audio
import AVFoundation

class AudioManager {
    static let shared = AudioManager()
    private var player: AVAudioPlayer?

    func playSound() {
        // This will play the default notification sound.
        // For more complex sounds, you would load a file here.
    }
}


// MARK: - Theme
enum Theme: String, CaseIterable, Identifiable {
    case system = "System"
    case light = "Light"
    case dark = "Dark"

    var id: String { self.rawValue }

    var colorScheme: ColorScheme? {
        switch self {
        case .system:
            return nil
        case .light:
            return .light
        case .dark:
            return .dark
        }
    }
}


// MARK: - Previews
struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        MainTabView()
            .environmentObject(SettingsManager())
            .environmentObject(StatisticsManager())
    }
}
